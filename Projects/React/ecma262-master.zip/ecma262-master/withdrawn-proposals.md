# Withdrawn Proposals

This list has moved [here](https://github.com/tc39/proposals/blob/master/inactive-proposals.md).
