module.exports = class Node {
  constructor(value) {
    this.value = value;
    this.leftChild = null; // will be a node
    this.rightChild = null; // will be a node
  }
};
