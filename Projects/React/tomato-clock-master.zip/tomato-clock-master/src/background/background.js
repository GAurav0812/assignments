import Timer from "./timer";

new Timer();
