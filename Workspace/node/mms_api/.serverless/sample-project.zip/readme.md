# get into project folder

cd node-api

# install dependencies

 npm install

# Run local dev server

npm run dev


