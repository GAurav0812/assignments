# Web Whiteboard ![visitors](https://visitor-badge.laobi.icu/badge?page_id=ayush8010720467_web_whiteboard)
Web Whiteboard is a project build with the similar functionality of whiteboard. It enables users to access various features like writing, clearing the entire whiteboard, and changing colors. [For demo please click here](https://ayush8010720467.github.io/web_whiteboard/)
<img src='./board.png'/>

## Contributing
Pull requests are welcome. For major changes, please open an [issue](https://github.com/ayush8010720467/web_whiteboard/issues) first to discuss what you would like to change.


## License
[MIT](https://choosealicense.com/licenses/mit/)
