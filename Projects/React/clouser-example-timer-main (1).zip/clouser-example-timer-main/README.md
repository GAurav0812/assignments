# clouser-example-timer
Clouser Example for running the timer
